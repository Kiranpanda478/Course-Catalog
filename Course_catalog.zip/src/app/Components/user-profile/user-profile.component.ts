import { Component } from '@angular/core';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent {
users = [{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
{
  username:"hiii",
  courses:"fsdd,sfdfds",
  progress:"50"
},
]
}
